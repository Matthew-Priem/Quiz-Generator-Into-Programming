flavor = input("Pick a flavor: ")

if flavor == "vanilla":
	print(f'Here is your vanilla ice cream!')
elif flavor == 'chocolate':
	print(f'Here is your chocolate ice cream!')
elif flavor == 'strawberry':
	print(f'Here is your chocolate ice cream!')
else:
	print(f"Sorry, we don't have {flavor} ice cream.")
