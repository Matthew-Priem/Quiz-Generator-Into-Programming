if Boolean_A:
	Block_X
if Boolean_B:
	Block_Y
