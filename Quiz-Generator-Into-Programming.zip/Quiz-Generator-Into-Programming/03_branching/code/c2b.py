if Boolean_A:
	Block_X
elif Boolean_B:
	Block_Y
