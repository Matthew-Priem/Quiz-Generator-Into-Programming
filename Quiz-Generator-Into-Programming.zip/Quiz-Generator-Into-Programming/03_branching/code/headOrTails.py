from random import randint
value = randint(0,1) #picks a random integer. Either 0 or 1.

print(value)
