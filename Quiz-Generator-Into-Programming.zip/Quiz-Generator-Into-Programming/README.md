# Intro-programming-quiz-code
This repo has several PDFs of sample into-programming questions and code to generate quizzes based on those lists.


This will eventually describe how to use this project to generate quizzes for your students.
