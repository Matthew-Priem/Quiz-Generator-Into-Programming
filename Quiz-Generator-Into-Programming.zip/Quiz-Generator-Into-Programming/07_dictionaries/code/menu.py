menu = {'burger':10, 'fries':4, 'soda':3}

print('Your output should be similar to this:')
for food, price in menu.items():
	print(f'{food} cost {price}')

