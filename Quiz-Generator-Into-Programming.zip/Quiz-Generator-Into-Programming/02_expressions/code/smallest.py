num1 = int(input("Pick a number: "))
num2 = int(input("Pick another number: "))
num3 = int(input("Pick another number: "))

smallest = min(num1, num2, num3)
print(f'The smallest number is {smallest}.')
