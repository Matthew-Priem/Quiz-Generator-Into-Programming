name = input("Enter your name: ")
age = input("Enter your age: ")

print(f"Hello {name}. {age} is a cool age!")
