color = input("Enter favorite color: ")
food = input("Enter favorite food: ")

print(f"I also like {color} and {food}!")
