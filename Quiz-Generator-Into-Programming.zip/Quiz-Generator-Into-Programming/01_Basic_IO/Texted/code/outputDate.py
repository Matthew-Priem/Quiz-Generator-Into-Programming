year = input("Enter year: ")
month = input("Enter month: ")
day = input("Enter day: ")

print(f"The date is {month} {day}, {year}.")
