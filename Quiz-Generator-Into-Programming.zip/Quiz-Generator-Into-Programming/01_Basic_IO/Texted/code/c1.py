my_int = 7
my_int = my_int + 3
print(my_int)
