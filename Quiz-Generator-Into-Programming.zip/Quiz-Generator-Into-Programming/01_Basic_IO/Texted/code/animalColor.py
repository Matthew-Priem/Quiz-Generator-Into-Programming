color = input("Pick a color: ")
animal = input("Pick an animal: ")

print(f"You picked a {color} {animal}.")
