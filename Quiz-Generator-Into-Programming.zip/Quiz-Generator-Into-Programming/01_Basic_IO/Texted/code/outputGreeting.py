first_name = input("Enter your first name: ")
last_name = input("Enter your last name: ")

print(f"Hello {first_name} {last_name}. How are you?")