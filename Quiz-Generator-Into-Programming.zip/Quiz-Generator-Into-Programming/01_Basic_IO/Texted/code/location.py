city = input("Enter a city: ")
state = input("Enter a state: ")

print(f"You are currently in {city}, {state}.")
