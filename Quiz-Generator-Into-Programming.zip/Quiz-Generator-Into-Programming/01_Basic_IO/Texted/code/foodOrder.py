food = input("enter a food: ")
drink = input("enter a drink: ")

print(f"Your order is a {food} and a {drink}.")
